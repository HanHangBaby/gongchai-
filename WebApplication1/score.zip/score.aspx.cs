﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;



namespace gongchai
{
    public partial class score : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string connstr = "server=.;database=gongchai;Integrated Security=SSPI";
            SqlConnection conn = new SqlConnection(connstr);
            Button btn = sender as Button;
            GridViewRow row = btn.Parent.Parent as GridViewRow;

            string cmdstr0 = string.Format("UPDATE T_mission SET total_points=time*0.6+status*0.4 WHERE mission_name='{0}'",row.Cells[0].Text);
            string cmdstr1 = string.Format("UPDATE T_people SET points=points+T_mission.total_points FROM T_mission WHERE T_people.mission_name='{0}'", row.Cells[0].Text);
            string cmdstr2 = string.Format("UPDATE T_people SET mission_name ='{0}' WHERE mission_name ='{1}'", null, row.Cells[0].Text);
            string cmdstr3 = " delete from T_mission where 公差名称='" + row.Cells[0].Text + "'";

            SqlCommand cmd0 = new SqlCommand(cmdstr0, conn);
            SqlCommand cmd1 = new SqlCommand(cmdstr1, conn);
            SqlCommand cmd2 = new SqlCommand(cmdstr2, conn);
            SqlCommand cmd3 = new SqlCommand(cmdstr3, conn);
            try
            {
                conn.Open();//打开数据库连接
                            //执行SQL语句并返回受影响的行数
                cmd0.ExecuteNonQuery();
                cmd1.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();
                GridView1.DataBind();//重新绑定gridview-起到刷新作用

                display();

            }
        }
    }
}